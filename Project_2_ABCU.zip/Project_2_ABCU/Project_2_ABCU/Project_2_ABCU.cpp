//============================================================================
// Name        : Project_2_ABCU.cpp
// Author      : Kiersten Grove
// Version     : 1.0
// Description : Project 2, SNHU: CS 300
//============================================================================

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

//#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

//Create course structure to hold course ID, name, and prerequisites
struct Course {
    string courseNum;
    string courseName;
    vector<string>preReqs;

    Course() {}
};

//BST nodes contain course info and left and right children

struct Node {
    Course course;
    Node* left;
    Node* right;

    Node() {
        left = nullptr;
        right = nullptr;
    }

    Node(Course aCourse) : Node() {
        this->course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class CourseBST {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void printSampleSchedule(Node* node);
    void printCourseInformation(Node* node, string courseNum);

public:
    CourseBST();
    virtual ~CourseBST();
    void DeleteRecursive(Node* node);
    void Insert(Course course);
    int NumPrerequisiteCourses(Course course);
    void PrintSampleSchedule();
    void PrintCourseInformation(string courseNum);
};

/**
 * Default constructor
 */
CourseBST::CourseBST() {
    //root is equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
CourseBST::~CourseBST() {
    // recurse from root deleting every node
    DeleteRecursive(root);
}

/**
* Delete BST nodes recursively used by the deconstructor
*/
void CourseBST::DeleteRecursive(Node* node) {
    if (node) {
        DeleteRecursive(node->left);
        DeleteRecursive(node->right);
        delete node;
    }
}

/**
 * Insert a node into the Binary Search Tree
 */
void CourseBST::Insert(Course course) {
    // If the root is not initialized
    if (root == nullptr)
        //initialize it with the current course info
        root = new Node(course);
    //Else, send the node to the addNode method
    else
        this->addNode(root, course);
}

/**
 * Returns the number of prereqs the passed course has
 */
int CourseBST::NumPrerequisiteCourses(Course course) {
    int count = 0;
    for (unsigned int i = 0; i < course.preReqs.size(); i++) {
        if (course.preReqs.at(i).length() > 0)
            count++;
    }
    return count;
}

/**
 * Passes BST root to private method
 */
void CourseBST::PrintSampleSchedule() {
    this->printSampleSchedule(root);
}

/**
 * Passes BST root and course ID to be searched for and displayed
 */
void CourseBST::PrintCourseInformation(string courseNum) {
    this->printCourseInformation(root, courseNum);
    }

/**
 * Determines and sets alphanumeric location,
 * if current child is a nullptr adds the node to the BST,
 * else keep traversing BST until nullptr is found
 */
void CourseBST::addNode(Node* node, Course course) {
    // Current courseNum is less than the current node's courseNum
    if (node->course.courseNum.compare(course.courseNum) > 0) {
        if (node->left == nullptr)
            node->left = new Node(course);
        else
            this->addNode(node->left, course);
    }
    else {
        if (node->right == nullptr)
            node->right = new Node(course);
        else
            this->addNode(node->right, course);
    }
}

/**
 * Recursively prints the loaded courses in order
 */
void CourseBST::printSampleSchedule(Node* node) {

    if (node != nullptr) {
        printSampleSchedule(node->left);
        cout << node->course.courseNum << ", " << node->course.courseName << endl;
        printSampleSchedule(node->right);
    }
    return;
}

/**
 * Displays a single courses information including its prereqs
 */
void CourseBST::printCourseInformation(Node* curr, string courseNum) {
    // Traverse BST until bottom reached or matching courseNum is found
    while (curr != nullptr) {
        //Passed courseNum matches the current courseNum
        if (curr->course.courseNum.compare(courseNum) == 0) {

            //Display course and get num prereqs
            cout << endl << curr->course.courseNum << ", " << curr->course.courseName << endl;
            unsigned int size = NumPrerequisiteCourses(curr->course);
            cout << "Prerequisite(s): ";

            //If prereqs exist, display each prereq with proper formatting
            unsigned int i = 0;
            for (i = 0; i < size; i++) {
                cout << curr->course.preReqs.at(i);
                if (i != size - 1)
                    cout << ", ";
            }
            // If there are no prereqs, inform user and return to stop the search
            if (i == 0)
                cout << "No prerequisites required.";
            cout << endl;
            return;
        }
        // Passed courseNum is smaller than the current courseNum so traverse left
        else if (courseNum.compare(curr->course.courseNum) < 0)
            curr = curr->left;

        // Passed courseNum is larger than the current courseNum so traverse right
        else
            curr = curr->right;
    }
    // nullptr has been reached but course hasn't been found/printed, inform user
    cout << "Course " << courseNum << " not found." << endl;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Load courses from cin choice for csv file
 */
bool loadCourses(string csvPath, CourseBST* coursesBST){
    //Open course file, get/separate each line and insert into BST
 //   try {
        ifstream courseFile(csvPath);

        if (courseFile.is_open()) {
            while (!courseFile.eof()) {
            //bool loadCourses(string csvPath, CourseBST* coursesBST) {
            
            //A vector will hold each csv that a course contains
                vector<string> courseInfo;
                string courseData;

                getline(courseFile, courseData);
                while (courseData.length() > 0) {

                    //Get substring of each course data, add to vector and delete
                    size_t comma = courseData.find(',');
                    if (comma < 100) {
                        //Any data field is allowed 99 chars or less
                        courseInfo.push_back(courseData.substr(0, comma));
                        courseData.erase(0, comma + 1);
                    }
                    //Add the last course after the final comma
                    else {
                        courseInfo.push_back(courseData.substr(0, courseData.length()));
                        courseData = "";
                    }
                }

                if (courseInfo.size() > 1) {
                    //Load the separated values into a course,
                    //insert into BST and close file
                    Course course;
                    course.courseNum = courseInfo[0];
                    course.courseName = courseInfo[1];

                    
                    for (unsigned int i = 2; i < courseInfo.size(); i++) {
                            course.preReqs.push_back(courseInfo[i]);
                    }
                    coursesBST->Insert(course);
                }
            }
            courseFile.close();
            return true;
        }
//    }
//      catch (csv::Error& e) {
//          cerr << e.what() << endl;
//    }
    return false;
}

//============================================================================
// Main method
//============================================================================

int main(int argc, char* argv[]){
        
    //Process command line argument
    string csvPath, courseId;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        courseId = argv[2];
        break;
    default:
        csvPath = "";
        break;
    }

    //Define BST and welcome the user
    CourseBST* coursesBST = nullptr;
    cout << "\nWelcome to the course planner,\n" << endl;

    //Making user choice a string and converting it to a int prevents invalid data
    string choice = "0";
    int userChoice = choice[0] - '0';

    //if not 9 or exit
    while (userChoice != 9) {
    
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Print Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "\nWhat would you like to do? ";
        cin >> choice;

        // Checks if user choice is a double digit
        if (choice.length() == 1)
            userChoice = choice[0] - '0';
        else
            userChoice = 0;

        bool success = 1;

        //Handle users choice from the menu
        switch (userChoice) {
        
            //Instantiate BST, get file path name, and load courses into BST
        case 1:
            if (coursesBST == nullptr)
                coursesBST = new CourseBST();
            if (csvPath.length() == 0) {
            
                cout << "Enter the file name that contains the course data: ";
                cin >> csvPath;

            }
            //Determine if the file was opened - load successful
            success = loadCourses(csvPath, coursesBST);
            if (success)
                cout << "Courses have been loaded.\n" << endl;
            else
                cout << "File not found.\n" << endl;
            csvPath = "";
            break;

            //Validate that a BST exists and print a sample schedule
        case 2:
            if (coursesBST != nullptr && success) {
                cout << "Here is a sample schedule:\n" << endl;
                coursesBST->PrintSampleSchedule();
                cout << endl;
            }
            else
                cout << "Load courses first - option 1\n" << endl;
            break;

            //Validate that a BST exists and search to display course info
        case 3:
            if (coursesBST != nullptr && success) {
                if (courseId.length() == 0) {
                    cout << "What course do you want to know about?";
                    cin >> courseId;
                    for (auto& userChoice : courseId)userChoice = toupper(userChoice);
                }
                coursesBST->PrintCourseInformation(courseId);
                cout << endl;
            }
            else
                cout << "Load courses first - option 1\n" << endl;
            courseId = "";
            break;

            //User entered invalid data or exited the program
        default:

            if (userChoice != 9)
                cout << choice << " is not a valid option\n" << endl;
            break;
        }
    }
    cout << "\nThank you for using the course planner!" << endl;

    return 0;
}

